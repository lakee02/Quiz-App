module.exports.x=function(req,res){
    return res.render('front_page',{
        title:"front"
    })
}